What I changed

- connection.php

  - Added basic session hardening (httponly, strict mode, secure when HTTPS).
  - Added CSRF helpers: csrf_token(), csrf_field(), verify_csrf().
  - Improved error logging instead of echoing DB errors.
  - Kept output escaping helper e().

- assets.css

  - New modern stylesheet with responsive layout, card styles, and subtle entrance/hover animations.

- login.php

  - Included assets.css.
  - Fixed duplicated form bug and added CSRF hidden field.
  - Uses the shared e() helper for output escaping.

- dashboard.php

  - Included assets.css and added a fade-in animation on the main container.

- showNews.php

  - Included assets.css.
  - Add CSRF verification for delete action and added csrf_field() to delete forms.
  - Images now use loading="lazy" and better alt text.

- showCategory.php, addNew.php, UpdateForm.php
  - Included assets.css where missing.
  - Added CSRF verification in POST handlers and inserted csrf_field() into forms.
  - Small UI tweaks to make forms consistent.

Notes & next steps

- I could not run `php -l` or functional tests because terminal execution was skipped; please run `php -l` on the edited PHP files, e.g.:

  php -l connection.php

- Test flows to exercise:

  - Login / register flow.
  - Add a news item (with and without image).
  - Update a news item (upload and replace image).
  - Delete news and categories (confirm CSRF error handling).

- Security suggestions (optional):

  - Move DB credentials to environment variables or a separate config outside webroot.
  - Use HTTPS in production and set session.cookie_secure.
  - Rate-limit login attempts and add password policies.

- Performance suggestions:
  - Serve minified CSS (assets.min.css) and compress images.
  - Add caching headers for static assets.

If you want, I can run a quick PHP lint and go fix any issues, or continue polishing the UI (typography, icons), or implement server-side image resizing.
